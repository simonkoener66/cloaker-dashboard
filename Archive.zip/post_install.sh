#!/bin/bash
./node_modules/bower/bin/bower install