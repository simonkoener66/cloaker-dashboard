=== IP-based Geolocation Filtering App

IP-based geolocation filtering application to redirect users to private or public urls based on entered criteria.
Based on MEAN stack(MongoDB, Express.js, AngularJS, Node.js), and implements Google Material Design using angular-material library.

Built by Simon Koener