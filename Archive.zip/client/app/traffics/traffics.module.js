(function () {
    'use strict';

    angular.module('app.traffics', []);
})(); 